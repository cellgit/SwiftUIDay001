Multiplatform Messages app for macOS, iOS, iPadOS in SwiftUI

![Messages](https://user-images.githubusercontent.com/110813/88483067-83d0c380-cf33-11ea-801c-947ad246ed65.png)
