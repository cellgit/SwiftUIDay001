//
//  MessagesApp.swift
//  Shared
//
//  Created by Jordan Singer on 6/28/20.
//

import SwiftUI

@main
struct MessagesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
