/*
See LICENSE folder for this sample’s licensing information.
*/

import SwiftUI

@main
struct HidingViewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
