/*
See LICENSE folder for this sample’s licensing information.
*/

import SwiftUI

@main
struct EventTileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
