# SwiftUI Concepts

Explore the project for the [Organizing and aligning content with stacks](https://developer.apple.com/tutorials/swiftui-concepts/organizing-and-aligning-content-with-stacks) tutorial.

